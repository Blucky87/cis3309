﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace matrix
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonMatrixAGenerate = new System.Windows.Forms.Button();
            this.buttonMatrixBGenerate = new System.Windows.Forms.Button();
            this.textBoxMatrixARows = new System.Windows.Forms.TextBox();
            this.textBoxMatrixBRows = new System.Windows.Forms.TextBox();
            this.textBoxMatrixAColumns = new System.Windows.Forms.TextBox();
            this.textBoxMatrixBColumns = new System.Windows.Forms.TextBox();
            this.textBoxMatrixADisplay = new System.Windows.Forms.TextBox();
            this.textBoxMatrixBDisplay = new System.Windows.Forms.TextBox();
            this.textBoxMatrixCDisplay = new System.Windows.Forms.TextBox();
            this.radioButtonMultiply = new System.Windows.Forms.RadioButton();
            this.radioButtonAddition = new System.Windows.Forms.RadioButton();
            this.radioButtonSubtraction = new System.Windows.Forms.RadioButton();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.buttonMatrixBIdentity = new System.Windows.Forms.Button();
            this.buttonMatrixAllClear = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.groupBoxOperations = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonClone = new System.Windows.Forms.Button();
            this.radioButtonABeq = new System.Windows.Forms.RadioButton();
            this.groupBoxOperations.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonMatrixAGenerate
            // 
            this.buttonMatrixAGenerate.Location = new System.Drawing.Point(11, 207);
            this.buttonMatrixAGenerate.Name = "buttonMatrixAGenerate";
            this.buttonMatrixAGenerate.Size = new System.Drawing.Size(127, 23);
            this.buttonMatrixAGenerate.TabIndex = 2;
            this.buttonMatrixAGenerate.Text = "Make Matrix A";
            this.buttonMatrixAGenerate.UseVisualStyleBackColor = true;
            this.buttonMatrixAGenerate.Click += new System.EventHandler(this.buttonMatrixAGenerate_Click);
            // 
            // buttonMatrixBGenerate
            // 
            this.buttonMatrixBGenerate.Location = new System.Drawing.Point(11, 236);
            this.buttonMatrixBGenerate.Name = "buttonMatrixBGenerate";
            this.buttonMatrixBGenerate.Size = new System.Drawing.Size(127, 23);
            this.buttonMatrixBGenerate.TabIndex = 5;
            this.buttonMatrixBGenerate.Text = "Make Matrix B";
            this.buttonMatrixBGenerate.UseVisualStyleBackColor = true;
            this.buttonMatrixBGenerate.Click += new System.EventHandler(this.buttonMatrixBGenerate_Click);
            // 
            // textBoxMatrixARows
            // 
            this.textBoxMatrixARows.Location = new System.Drawing.Point(144, 209);
            this.textBoxMatrixARows.Name = "textBoxMatrixARows";
            this.textBoxMatrixARows.Size = new System.Drawing.Size(100, 20);
            this.textBoxMatrixARows.TabIndex = 0;
            this.textBoxMatrixARows.Text = "3";
            // 
            // textBoxMatrixBRows
            // 
            this.textBoxMatrixBRows.Location = new System.Drawing.Point(144, 239);
            this.textBoxMatrixBRows.Name = "textBoxMatrixBRows";
            this.textBoxMatrixBRows.Size = new System.Drawing.Size(100, 20);
            this.textBoxMatrixBRows.TabIndex = 3;
            this.textBoxMatrixBRows.Text = "3";
            // 
            // textBoxMatrixAColumns
            // 
            this.textBoxMatrixAColumns.Location = new System.Drawing.Point(250, 210);
            this.textBoxMatrixAColumns.Name = "textBoxMatrixAColumns";
            this.textBoxMatrixAColumns.Size = new System.Drawing.Size(100, 20);
            this.textBoxMatrixAColumns.TabIndex = 1;
            this.textBoxMatrixAColumns.Text = "3";
            // 
            // textBoxMatrixBColumns
            // 
            this.textBoxMatrixBColumns.Location = new System.Drawing.Point(250, 238);
            this.textBoxMatrixBColumns.Name = "textBoxMatrixBColumns";
            this.textBoxMatrixBColumns.Size = new System.Drawing.Size(100, 20);
            this.textBoxMatrixBColumns.TabIndex = 4;
            this.textBoxMatrixBColumns.Text = "3";
            // 
            // textBoxMatrixADisplay
            // 
            this.textBoxMatrixADisplay.Location = new System.Drawing.Point(11, 28);
            this.textBoxMatrixADisplay.Multiline = true;
            this.textBoxMatrixADisplay.Name = "textBoxMatrixADisplay";
            this.textBoxMatrixADisplay.ReadOnly = true;
            this.textBoxMatrixADisplay.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxMatrixADisplay.Size = new System.Drawing.Size(150, 150);
            this.textBoxMatrixADisplay.TabIndex = 12;
            this.textBoxMatrixADisplay.WordWrap = false;
            // 
            // textBoxMatrixBDisplay
            // 
            this.textBoxMatrixBDisplay.Location = new System.Drawing.Point(192, 28);
            this.textBoxMatrixBDisplay.Multiline = true;
            this.textBoxMatrixBDisplay.Name = "textBoxMatrixBDisplay";
            this.textBoxMatrixBDisplay.ReadOnly = true;
            this.textBoxMatrixBDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxMatrixBDisplay.Size = new System.Drawing.Size(150, 150);
            this.textBoxMatrixBDisplay.TabIndex = 13;
            this.textBoxMatrixBDisplay.WordWrap = false;
            // 
            // textBoxMatrixCDisplay
            // 
            this.textBoxMatrixCDisplay.Location = new System.Drawing.Point(373, 28);
            this.textBoxMatrixCDisplay.Multiline = true;
            this.textBoxMatrixCDisplay.Name = "textBoxMatrixCDisplay";
            this.textBoxMatrixCDisplay.ReadOnly = true;
            this.textBoxMatrixCDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxMatrixCDisplay.Size = new System.Drawing.Size(150, 150);
            this.textBoxMatrixCDisplay.TabIndex = 14;
            this.textBoxMatrixCDisplay.WordWrap = false;
            // 
            // radioButtonMultiply
            // 
            this.radioButtonMultiply.AutoSize = true;
            this.radioButtonMultiply.Checked = true;
            this.radioButtonMultiply.Location = new System.Drawing.Point(19, 19);
            this.radioButtonMultiply.Name = "radioButtonMultiply";
            this.radioButtonMultiply.Size = new System.Drawing.Size(60, 17);
            this.radioButtonMultiply.TabIndex = 7;
            this.radioButtonMultiply.TabStop = true;
            this.radioButtonMultiply.Text = "Multiply";
            this.radioButtonMultiply.UseVisualStyleBackColor = true;
            this.radioButtonMultiply.CheckedChanged += new System.EventHandler(this.radioButtonMultiply_CheckedChanged);
            // 
            // radioButtonAddition
            // 
            this.radioButtonAddition.AutoSize = true;
            this.radioButtonAddition.Location = new System.Drawing.Point(85, 19);
            this.radioButtonAddition.Name = "radioButtonAddition";
            this.radioButtonAddition.Size = new System.Drawing.Size(44, 17);
            this.radioButtonAddition.TabIndex = 8;
            this.radioButtonAddition.TabStop = true;
            this.radioButtonAddition.Text = "Add";
            this.radioButtonAddition.UseVisualStyleBackColor = true;
            this.radioButtonAddition.CheckedChanged += new System.EventHandler(this.radioButtonAddition_CheckedChanged);
            // 
            // radioButtonSubtraction
            // 
            this.radioButtonSubtraction.AutoSize = true;
            this.radioButtonSubtraction.Location = new System.Drawing.Point(135, 19);
            this.radioButtonSubtraction.Name = "radioButtonSubtraction";
            this.radioButtonSubtraction.Size = new System.Drawing.Size(65, 17);
            this.radioButtonSubtraction.TabIndex = 9;
            this.radioButtonSubtraction.TabStop = true;
            this.radioButtonSubtraction.Text = "Subtract";
            this.radioButtonSubtraction.UseVisualStyleBackColor = true;
            this.radioButtonSubtraction.CheckedChanged += new System.EventHandler(this.radioButtonSubtraction_CheckedChanged);
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Location = new System.Drawing.Point(11, 323);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(85, 23);
            this.buttonCalculate.TabIndex = 10;
            this.buttonCalculate.Text = "Calculate";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // buttonMatrixBIdentity
            // 
            this.buttonMatrixBIdentity.Location = new System.Drawing.Point(356, 237);
            this.buttonMatrixBIdentity.Name = "buttonMatrixBIdentity";
            this.buttonMatrixBIdentity.Size = new System.Drawing.Size(111, 23);
            this.buttonMatrixBIdentity.TabIndex = 6;
            this.buttonMatrixBIdentity.Text = "Make B Identity";
            this.buttonMatrixBIdentity.UseVisualStyleBackColor = true;
            this.buttonMatrixBIdentity.Click += new System.EventHandler(this.buttonMatrixBIdentity_Click);
            // 
            // buttonMatrixAllClear
            // 
            this.buttonMatrixAllClear.Location = new System.Drawing.Point(338, 323);
            this.buttonMatrixAllClear.Name = "buttonMatrixAllClear";
            this.buttonMatrixAllClear.Size = new System.Drawing.Size(104, 23);
            this.buttonMatrixAllClear.TabIndex = 11;
            this.buttonMatrixAllClear.Text = "Clear Matrices";
            this.buttonMatrixAllClear.UseVisualStyleBackColor = true;
            this.buttonMatrixAllClear.Click += new System.EventHandler(this.buttonMatrixAllClear_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(448, 323);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 15;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // groupBoxOperations
            // 
            this.groupBoxOperations.Controls.Add(this.radioButtonABeq);
            this.groupBoxOperations.Controls.Add(this.radioButtonAddition);
            this.groupBoxOperations.Controls.Add(this.radioButtonSubtraction);
            this.groupBoxOperations.Controls.Add(this.radioButtonMultiply);
            this.groupBoxOperations.Location = new System.Drawing.Point(12, 265);
            this.groupBoxOperations.Name = "groupBoxOperations";
            this.groupBoxOperations.Size = new System.Drawing.Size(275, 52);
            this.groupBoxOperations.TabIndex = 16;
            this.groupBoxOperations.TabStop = false;
            this.groupBoxOperations.Text = "Select Operation";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(177, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Rows";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(272, 193);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Columns";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Matrix A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(189, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Matrix B";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(370, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Matrix C";
            // 
            // button1
            // 
            this.buttonClone.Location = new System.Drawing.Point(356, 208);
            this.buttonClone.Name = "buttonClone";
            this.buttonClone.Size = new System.Drawing.Size(111, 23);
            this.buttonClone.TabIndex = 22;
            this.buttonClone.Text = "Make B Copy of A";
            this.buttonClone.UseVisualStyleBackColor = true;
            this.buttonClone.Click += new System.EventHandler(this.button1_Click);
            // 
            // rbnABEq
            // 
            this.radioButtonABeq.AutoSize = true;
            this.radioButtonABeq.Location = new System.Drawing.Point(204, 19);
            this.radioButtonABeq.Name = "radioButtonABeq";
            this.radioButtonABeq.Size = new System.Drawing.Size(57, 17);
            this.radioButtonABeq.TabIndex = 10;
            this.radioButtonABeq.TabStop = true;
            this.radioButtonABeq.Text = "A == B";
            this.radioButtonABeq.UseVisualStyleBackColor = true;
            this.radioButtonABeq.CheckedChanged += new System.EventHandler(this.radioButtonABeq_CheckedChanged);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(534, 355);
            this.Controls.Add(this.buttonClone);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonMatrixAllClear);
            this.Controls.Add(this.buttonMatrixBIdentity);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.textBoxMatrixCDisplay);
            this.Controls.Add(this.textBoxMatrixBDisplay);
            this.Controls.Add(this.textBoxMatrixADisplay);
            this.Controls.Add(this.textBoxMatrixBColumns);
            this.Controls.Add(this.textBoxMatrixAColumns);
            this.Controls.Add(this.textBoxMatrixBRows);
            this.Controls.Add(this.textBoxMatrixARows);
            this.Controls.Add(this.buttonMatrixBGenerate);
            this.Controls.Add(this.buttonMatrixAGenerate);
            this.Controls.Add(this.groupBoxOperations);
            this.Name = "Form1";
            this.Text = "Matrix Ops";
            this.groupBoxOperations.ResumeLayout(false);
            this.groupBoxOperations.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonMatrixAGenerate;
        private System.Windows.Forms.Button buttonMatrixBGenerate;
        private System.Windows.Forms.TextBox textBoxMatrixARows;
        private System.Windows.Forms.TextBox textBoxMatrixBRows;
        private System.Windows.Forms.TextBox textBoxMatrixAColumns;
        private System.Windows.Forms.TextBox textBoxMatrixBColumns;
        private System.Windows.Forms.TextBox textBoxMatrixADisplay;
        private System.Windows.Forms.TextBox textBoxMatrixBDisplay;
        private System.Windows.Forms.TextBox textBoxMatrixCDisplay;
        private System.Windows.Forms.RadioButton radioButtonMultiply;
        private System.Windows.Forms.RadioButton radioButtonAddition;
        private System.Windows.Forms.RadioButton radioButtonSubtraction;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Button buttonMatrixBIdentity;
        private System.Windows.Forms.Button buttonMatrixAllClear;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.GroupBox groupBoxOperations;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private RadioButton radioButtonABeq;
        private Button buttonClone;
    }
}

