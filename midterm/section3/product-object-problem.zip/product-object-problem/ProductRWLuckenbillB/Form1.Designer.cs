﻿namespace ProductRWLuckenbillB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxType = new System.Windows.Forms.TextBox();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.textBoxDescription = new System.Windows.Forms.TextBox();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.textBoxVar1 = new System.Windows.Forms.TextBox();
            this.textBoxVar2 = new System.Windows.Forms.TextBox();
            this.textBoxVar3 = new System.Windows.Forms.TextBox();
            this.textBoxVar4 = new System.Windows.Forms.TextBox();
            this.textBoxVar5 = new System.Windows.Forms.TextBox();
            this.textBoxVar6 = new System.Windows.Forms.TextBox();
            this.textBoxVar7 = new System.Windows.Forms.TextBox();
            this.buttonReadSS = new System.Windows.Forms.Button();
            this.buttonWriteSS = new System.Windows.Forms.Button();
            this.buttonPreviousProduct = new System.Windows.Forms.Button();
            this.buttonNextProduct = new System.Windows.Forms.Button();
            this.buttonReadBin = new System.Windows.Forms.Button();
            this.buttonWriteBin = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.labelType = new System.Windows.Forms.Label();
            this.labelId = new System.Windows.Forms.Label();
            this.labelDescription = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.labelVar1 = new System.Windows.Forms.Label();
            this.labelVar2 = new System.Windows.Forms.Label();
            this.labelVar3 = new System.Windows.Forms.Label();
            this.labelVar4 = new System.Windows.Forms.Label();
            this.labelVar5 = new System.Windows.Forms.Label();
            this.labelVar6 = new System.Windows.Forms.Label();
            this.labelVar7 = new System.Windows.Forms.Label();
            this.textBoxVar8 = new System.Windows.Forms.TextBox();
            this.labelVar8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxType
            // 
            this.textBoxType.Location = new System.Drawing.Point(136, 13);
            this.textBoxType.Name = "textBoxType";
            this.textBoxType.Size = new System.Drawing.Size(206, 20);
            this.textBoxType.TabIndex = 0;
            // 
            // textBoxId
            // 
            this.textBoxId.Location = new System.Drawing.Point(136, 39);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(206, 20);
            this.textBoxId.TabIndex = 1;
            // 
            // textBoxDescription
            // 
            this.textBoxDescription.Location = new System.Drawing.Point(136, 65);
            this.textBoxDescription.Name = "textBoxDescription";
            this.textBoxDescription.Size = new System.Drawing.Size(206, 20);
            this.textBoxDescription.TabIndex = 2;
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(136, 91);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(206, 20);
            this.textBoxPrice.TabIndex = 3;
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(136, 117);
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.Size = new System.Drawing.Size(206, 20);
            this.textBoxQuantity.TabIndex = 4;
            // 
            // textBoxVar1
            // 
            this.textBoxVar1.Location = new System.Drawing.Point(136, 143);
            this.textBoxVar1.Name = "textBoxVar1";
            this.textBoxVar1.Size = new System.Drawing.Size(206, 20);
            this.textBoxVar1.TabIndex = 5;
            this.textBoxVar1.Visible = false;
            // 
            // textBoxVar2
            // 
            this.textBoxVar2.Location = new System.Drawing.Point(136, 169);
            this.textBoxVar2.Name = "textBoxVar2";
            this.textBoxVar2.Size = new System.Drawing.Size(206, 20);
            this.textBoxVar2.TabIndex = 6;
            this.textBoxVar2.Visible = false;
            // 
            // textBoxVar3
            // 
            this.textBoxVar3.Location = new System.Drawing.Point(136, 195);
            this.textBoxVar3.Name = "textBoxVar3";
            this.textBoxVar3.Size = new System.Drawing.Size(206, 20);
            this.textBoxVar3.TabIndex = 7;
            this.textBoxVar3.Visible = false;
            // 
            // textBoxVar4
            // 
            this.textBoxVar4.Location = new System.Drawing.Point(136, 221);
            this.textBoxVar4.Name = "textBoxVar4";
            this.textBoxVar4.Size = new System.Drawing.Size(206, 20);
            this.textBoxVar4.TabIndex = 8;
            this.textBoxVar4.Visible = false;
            // 
            // textBoxVar5
            // 
            this.textBoxVar5.Location = new System.Drawing.Point(136, 247);
            this.textBoxVar5.Name = "textBoxVar5";
            this.textBoxVar5.Size = new System.Drawing.Size(206, 20);
            this.textBoxVar5.TabIndex = 9;
            this.textBoxVar5.Visible = false;
            // 
            // textBoxVar6
            // 
            this.textBoxVar6.Location = new System.Drawing.Point(136, 273);
            this.textBoxVar6.Name = "textBoxVar6";
            this.textBoxVar6.Size = new System.Drawing.Size(206, 20);
            this.textBoxVar6.TabIndex = 10;
            this.textBoxVar6.Visible = false;
            // 
            // textBoxVar7
            // 
            this.textBoxVar7.Location = new System.Drawing.Point(136, 299);
            this.textBoxVar7.Name = "textBoxVar7";
            this.textBoxVar7.Size = new System.Drawing.Size(206, 20);
            this.textBoxVar7.TabIndex = 11;
            this.textBoxVar7.Visible = false;
            // 
            // buttonReadSS
            // 
            this.buttonReadSS.Location = new System.Drawing.Point(15, 362);
            this.buttonReadSS.Name = "buttonReadSS";
            this.buttonReadSS.Size = new System.Drawing.Size(75, 23);
            this.buttonReadSS.TabIndex = 12;
            this.buttonReadSS.Text = "Read";
            this.buttonReadSS.UseVisualStyleBackColor = true;
            this.buttonReadSS.Click += new System.EventHandler(this.buttonReadSS_Click);
            // 
            // buttonWriteSS
            // 
            this.buttonWriteSS.Location = new System.Drawing.Point(96, 362);
            this.buttonWriteSS.Name = "buttonWriteSS";
            this.buttonWriteSS.Size = new System.Drawing.Size(75, 23);
            this.buttonWriteSS.TabIndex = 13;
            this.buttonWriteSS.Text = "Write";
            this.buttonWriteSS.UseVisualStyleBackColor = true;
            this.buttonWriteSS.Click += new System.EventHandler(this.buttonWriteSS_Click);
            // 
            // buttonPreviousProduct
            // 
            this.buttonPreviousProduct.Location = new System.Drawing.Point(15, 391);
            this.buttonPreviousProduct.Name = "buttonPreviousProduct";
            this.buttonPreviousProduct.Size = new System.Drawing.Size(75, 23);
            this.buttonPreviousProduct.TabIndex = 14;
            this.buttonPreviousProduct.Text = "Previous";
            this.buttonPreviousProduct.UseVisualStyleBackColor = true;
            this.buttonPreviousProduct.Click += new System.EventHandler(this.buttonPreviousProduct_Click);
            // 
            // buttonNextProduct
            // 
            this.buttonNextProduct.Location = new System.Drawing.Point(96, 391);
            this.buttonNextProduct.Name = "buttonNextProduct";
            this.buttonNextProduct.Size = new System.Drawing.Size(75, 23);
            this.buttonNextProduct.TabIndex = 15;
            this.buttonNextProduct.Text = "Next";
            this.buttonNextProduct.UseVisualStyleBackColor = true;
            this.buttonNextProduct.Click += new System.EventHandler(this.buttonNextProduct_Click);
            // 
            // buttonReadBin
            // 
            this.buttonReadBin.Location = new System.Drawing.Point(15, 420);
            this.buttonReadBin.Name = "buttonReadBin";
            this.buttonReadBin.Size = new System.Drawing.Size(75, 23);
            this.buttonReadBin.TabIndex = 16;
            this.buttonReadBin.Text = "Read Bin";
            this.buttonReadBin.UseVisualStyleBackColor = true;
            this.buttonReadBin.Click += new System.EventHandler(this.buttonReadBin_Click);
            // 
            // buttonWriteBin
            // 
            this.buttonWriteBin.Location = new System.Drawing.Point(96, 420);
            this.buttonWriteBin.Name = "buttonWriteBin";
            this.buttonWriteBin.Size = new System.Drawing.Size(75, 23);
            this.buttonWriteBin.TabIndex = 17;
            this.buttonWriteBin.Text = "Write Bin";
            this.buttonWriteBin.UseVisualStyleBackColor = true;
            this.buttonWriteBin.Click += new System.EventHandler(this.buttonWriteBin_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(267, 420);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 18;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(30, 13);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(31, 13);
            this.labelType.TabIndex = 19;
            this.labelType.Text = "Type";
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.Location = new System.Drawing.Point(30, 39);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(18, 13);
            this.labelId.TabIndex = 20;
            this.labelId.Text = "ID";
            // 
            // labelDescription
            // 
            this.labelDescription.AutoSize = true;
            this.labelDescription.Location = new System.Drawing.Point(30, 65);
            this.labelDescription.Name = "labelDescription";
            this.labelDescription.Size = new System.Drawing.Size(60, 13);
            this.labelDescription.TabIndex = 21;
            this.labelDescription.Text = "Description";
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Location = new System.Drawing.Point(30, 91);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(31, 13);
            this.labelPrice.TabIndex = 22;
            this.labelPrice.Text = "Price";
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Location = new System.Drawing.Point(30, 117);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(46, 13);
            this.labelQuantity.TabIndex = 23;
            this.labelQuantity.Text = "Quantity";
            // 
            // labelVar1
            // 
            this.labelVar1.AutoSize = true;
            this.labelVar1.Location = new System.Drawing.Point(30, 143);
            this.labelVar1.Name = "labelVar1";
            this.labelVar1.Size = new System.Drawing.Size(29, 13);
            this.labelVar1.TabIndex = 24;
            this.labelVar1.Text = "Var1";
            this.labelVar1.Visible = false;
            // 
            // labelVar2
            // 
            this.labelVar2.AutoSize = true;
            this.labelVar2.Location = new System.Drawing.Point(30, 169);
            this.labelVar2.Name = "labelVar2";
            this.labelVar2.Size = new System.Drawing.Size(29, 13);
            this.labelVar2.TabIndex = 25;
            this.labelVar2.Text = "Var2";
            this.labelVar2.Visible = false;
            // 
            // labelVar3
            // 
            this.labelVar3.AutoSize = true;
            this.labelVar3.Location = new System.Drawing.Point(30, 195);
            this.labelVar3.Name = "labelVar3";
            this.labelVar3.Size = new System.Drawing.Size(29, 13);
            this.labelVar3.TabIndex = 26;
            this.labelVar3.Text = "Var3";
            this.labelVar3.Visible = false;
            // 
            // labelVar4
            // 
            this.labelVar4.AutoSize = true;
            this.labelVar4.Location = new System.Drawing.Point(30, 221);
            this.labelVar4.Name = "labelVar4";
            this.labelVar4.Size = new System.Drawing.Size(29, 13);
            this.labelVar4.TabIndex = 27;
            this.labelVar4.Text = "Var4";
            this.labelVar4.Visible = false;
            // 
            // labelVar5
            // 
            this.labelVar5.AutoSize = true;
            this.labelVar5.Location = new System.Drawing.Point(30, 247);
            this.labelVar5.Name = "labelVar5";
            this.labelVar5.Size = new System.Drawing.Size(29, 13);
            this.labelVar5.TabIndex = 28;
            this.labelVar5.Text = "Var5";
            this.labelVar5.Visible = false;
            // 
            // labelVar6
            // 
            this.labelVar6.AutoSize = true;
            this.labelVar6.Location = new System.Drawing.Point(30, 273);
            this.labelVar6.Name = "labelVar6";
            this.labelVar6.Size = new System.Drawing.Size(29, 13);
            this.labelVar6.TabIndex = 29;
            this.labelVar6.Text = "Var6";
            this.labelVar6.Visible = false;
            // 
            // labelVar7
            // 
            this.labelVar7.AutoSize = true;
            this.labelVar7.Location = new System.Drawing.Point(30, 299);
            this.labelVar7.Name = "labelVar7";
            this.labelVar7.Size = new System.Drawing.Size(29, 13);
            this.labelVar7.TabIndex = 30;
            this.labelVar7.Text = "Var7";
            this.labelVar7.Visible = false;
            // 
            // textBoxVar8
            // 
            this.textBoxVar8.Location = new System.Drawing.Point(136, 325);
            this.textBoxVar8.Name = "textBoxVar8";
            this.textBoxVar8.Size = new System.Drawing.Size(206, 20);
            this.textBoxVar8.TabIndex = 31;
            this.textBoxVar8.Visible = false;
            // 
            // labelVar8
            // 
            this.labelVar8.AutoSize = true;
            this.labelVar8.Location = new System.Drawing.Point(30, 325);
            this.labelVar8.Name = "labelVar8";
            this.labelVar8.Size = new System.Drawing.Size(29, 13);
            this.labelVar8.TabIndex = 32;
            this.labelVar8.Text = "Var8";
            this.labelVar8.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 455);
            this.Controls.Add(this.labelVar8);
            this.Controls.Add(this.textBoxVar8);
            this.Controls.Add(this.labelVar7);
            this.Controls.Add(this.labelVar6);
            this.Controls.Add(this.labelVar5);
            this.Controls.Add(this.labelVar4);
            this.Controls.Add(this.labelVar3);
            this.Controls.Add(this.labelVar2);
            this.Controls.Add(this.labelVar1);
            this.Controls.Add(this.labelQuantity);
            this.Controls.Add(this.labelPrice);
            this.Controls.Add(this.labelDescription);
            this.Controls.Add(this.labelId);
            this.Controls.Add(this.labelType);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonWriteBin);
            this.Controls.Add(this.buttonReadBin);
            this.Controls.Add(this.buttonNextProduct);
            this.Controls.Add(this.buttonPreviousProduct);
            this.Controls.Add(this.buttonWriteSS);
            this.Controls.Add(this.buttonReadSS);
            this.Controls.Add(this.textBoxVar7);
            this.Controls.Add(this.textBoxVar6);
            this.Controls.Add(this.textBoxVar5);
            this.Controls.Add(this.textBoxVar4);
            this.Controls.Add(this.textBoxVar3);
            this.Controls.Add(this.textBoxVar2);
            this.Controls.Add(this.textBoxVar1);
            this.Controls.Add(this.textBoxQuantity);
            this.Controls.Add(this.textBoxPrice);
            this.Controls.Add(this.textBoxDescription);
            this.Controls.Add(this.textBoxId);
            this.Controls.Add(this.textBoxType);
            this.Name = "Form1";
            this.Text = "Products";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxType;
        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.TextBox textBoxDescription;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.TextBox textBoxQuantity;
        private System.Windows.Forms.TextBox textBoxVar1;
        private System.Windows.Forms.TextBox textBoxVar2;
        private System.Windows.Forms.TextBox textBoxVar3;
        private System.Windows.Forms.TextBox textBoxVar4;
        private System.Windows.Forms.TextBox textBoxVar5;
        private System.Windows.Forms.TextBox textBoxVar6;
        private System.Windows.Forms.TextBox textBoxVar7;
        private System.Windows.Forms.Button buttonReadSS;
        private System.Windows.Forms.Button buttonWriteSS;
        private System.Windows.Forms.Button buttonPreviousProduct;
        private System.Windows.Forms.Button buttonNextProduct;
        private System.Windows.Forms.Button buttonReadBin;
        private System.Windows.Forms.Button buttonWriteBin;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.Label labelDescription;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Label labelVar1;
        private System.Windows.Forms.Label labelVar2;
        private System.Windows.Forms.Label labelVar3;
        private System.Windows.Forms.Label labelVar4;
        private System.Windows.Forms.Label labelVar5;
        private System.Windows.Forms.Label labelVar6;
        private System.Windows.Forms.Label labelVar7;
        private System.Windows.Forms.TextBox textBoxVar8;
        private System.Windows.Forms.Label labelVar8;
    }
}

